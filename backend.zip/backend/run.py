# app/run.py
from app import create_app, db
from app.models import User, Service, ServiceRequest

app = create_app()

# Use app context explicitly if needed
with app.app_context():
    db.create_all()  # Creates the tables

if __name__ == "__main__":
    app.run(debug=True)
