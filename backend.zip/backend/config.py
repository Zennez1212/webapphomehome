import os
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Folder to store CSV exports
EXPORT_FOLDER = os.path.join(BASE_DIR, 'exports')

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key')
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'sqlite:///app.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY', 'your-jwt-secret')

    # Flask-Caching configuration with Redis
    CACHE_TYPE = "RedisCache"  # Use Redis for caching
    CACHE_DEFAULT_TIMEOUT = 300  # Cache timeout in seconds
    CACHE_REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/0')  # Redis server URI

    # Celery Configuration
    CELERY_BROKER_URL = os.getenv('CELERY_BROKER_URL', 'redis://localhost:6379/0')  # Redis as broker
    CELERY_RESULT_BACKEND = os.getenv('CELERY_RESULT_BACKEND', 'redis://localhost:6379/0')  # Redis for result storage

    # Optional: Configure Redis caching timeout
    CACHE_REDIS_TIMEOUT = 60  # Cache expiration time in seconds

    # For production, you may want to set the database URI and Redis URI via environment variables
