from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from datetime import datetime
from app.models import ServiceRequest, Service, User
from app.extensions import db, get_cached_services

# Blueprint for Service Requests
bp = Blueprint('service_requests', __name__, url_prefix='/service-requests')

# Customer: Create a Service Request
@bp.route('/', methods=['POST'])
@login_required
def create_service_request():
    if current_user.role != 'customer':
        return jsonify({"message": "Unauthorized"}), 403

    data = request.get_json()
    service_id = data.get('service_id')

    # Validate Service
    service = Service.query.get(service_id)
    if not service:
        return jsonify({"message": "Service not found"}), 404

    # Create Service Request
    service_request = ServiceRequest(
        service_id=service_id,
        customer_id=current_user.id,
        service_status='requested'
    )
    db.session.add(service_request)
    db.session.commit()

    return jsonify({"message": "Service request created successfully"}), 201

# Customer: Edit a Service Request
@bp.route('/<int:request_id>', methods=['PUT'])
@login_required
def edit_service_request(request_id):
    if current_user.role != 'customer':
        return jsonify({"message": "Unauthorized"}), 403

    # Validate Service Request
    service_request = ServiceRequest.query.get(request_id)
    if not service_request or service_request.customer_id != current_user.id:
        return jsonify({"message": "Request not found or not authorized"}), 404

    # Update Service Request
    data = request.get_json()
    service_request.remarks = data.get('remarks', service_request.remarks)
    service_request.service_status = data.get('service_status', service_request.service_status)
    db.session.commit()

    return jsonify({"message": "Service request updated successfully"}), 200

# Customer: Close a Service Request
@bp.route('/<int:request_id>/close', methods=['POST'])
@login_required
def close_service_request(request_id):
    if current_user.role != 'customer':
        return jsonify({"message": "Unauthorized"}), 403

    # Validate Service Request
    service_request = ServiceRequest.query.get(request_id)
    if not service_request or service_request.customer_id != current_user.id:
        return jsonify({"message": "Request not found or not authorized"}), 404

    # Close Service Request
    service_request.service_status = 'completed'
    service_request.date_of_completion = datetime.utcnow()
    db.session.commit()

    return jsonify({"message": "Service request closed successfully"}), 200

# Professional: Accept/Reject/Complete Service Request
@bp.route('/<int:request_id>/action', methods=['POST'])
@login_required
def action_service_request(request_id):
    if current_user.role != 'professional':
        return jsonify({"message": "Unauthorized"}), 403

    # Validate Service Request
    service_request = ServiceRequest.query.get(request_id)
    if not service_request:
        return jsonify({"message": "Request not found"}), 404

    action = request.json.get('action')
    if action == 'accept':
        service_request.service_status = 'assigned'
        service_request.professional_id = current_user.id  # Assign to the current professional
    elif action == 'reject':
        service_request.service_status = 'rejected'
    elif action == 'complete':
        service_request.service_status = 'completed'
        service_request.date_of_completion = datetime.utcnow()
    else:
        return jsonify({"message": "Invalid action"}), 400

    db.session.commit()
    return jsonify({"message": f"Service request {action} processed"}), 200

# Customer & Professional: Fetch Service Requests
@bp.route('/', methods=['GET'])
@login_required
def fetch_service_requests():
    if current_user.role == 'customer':
        service_requests = ServiceRequest.query.filter_by(customer_id=current_user.id).all()
    elif current_user.role == 'professional':
        service_requests = ServiceRequest.query.filter_by(professional_id=current_user.id).all()
    else:
        return jsonify({"message": "Unauthorized"}), 403

    # Serialize data for response
    response = [
        {
            "id": req.id,
            "service_id": req.service_id,
            "service_name": req.service.name if req.service else None,
            "status": req.service_status,
            "date_of_request": req.date_of_request,
            "date_of_completion": req.date_of_completion,
            "remarks": req.remarks,
        }
        for req in service_requests
    ]
    return jsonify({"service_requests": response}), 200
