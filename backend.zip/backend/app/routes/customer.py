from flask import Blueprint, jsonify, request, render_template
from flask_login import login_required, current_user
from app.models import ServiceRequest, ServiceOffer, Service
from app.extensions import db
from datetime import datetime

bp = Blueprint('customer', __name__, url_prefix='/customer')

# Decorator for checking if the current user is a customer
from functools import wraps  # Import wraps from functools

def customer_required(f):
    @wraps(f)  # Ensure the wrapped function keeps its original name
    def wrapped(*args, **kwargs):
        if current_user.role != 'customer':
            return jsonify({"message": "Unauthorized"}), 403
        return f(*args, **kwargs)
    return wrapped

# Create a Service Request
@bp.route('/service_requests', methods=['POST'])
@login_required
@customer_required
def create_service_request():
    data = request.json
    new_request = ServiceRequest(
        customer_id=current_user.id,
        service_id=data['service_id'],
        date_of_request=datetime.utcnow(),
        remarks=data.get('remarks', '')
    )
    db.session.add(new_request)
    db.session.commit()
    return jsonify({"message": "Service request created successfully"}), 201


# Add a rating for a service request (POST request)
@bp.route('/service_requests/<int:service_request_id>/rate', methods=['POST'])
@login_required
@customer_required
def rate_service(service_request_id):
    # Fetch the service request
    service_request = ServiceRequest.query.get(service_request_id)
    if not service_request:
        return jsonify({"message": "Service request not found"}), 404
    
    if service_request.customer_id != current_user.id:
        return jsonify({"message": "You cannot rate this service request"}), 403

    if service_request.service_status != 'completed':
        return jsonify({"message": "Service not completed yet, cannot rate"}), 400

    # Get rating and feedback from request
    data = request.json
    rating = data.get('rating')
    feedback = data.get('feedback')

    if rating < 1 or rating > 5:
        return jsonify({"message": "Rating must be between 1 and 5"}), 400

    # Update the service request with the rating and feedback
    service_request.rating = rating
    service_request.feedback = feedback
    db.session.commit()

    return jsonify({"message": "Service rated successfully"}), 200


# Get All Service Requests for the Logged-in Customer
@bp.route('/service_requests', methods=['GET'])
@login_required
@customer_required
def get_service_requests():
    requests = ServiceRequest.query.filter_by(customer_id=current_user.id).all()
    request_list = [{
        "id": req.id,
        "service_name": req.service.name,
        "professional_name": req.professional.username if req.professional else "N/A",
        "status": req.service_status,
        "remarks": req.remarks,
        "date_of_request": req.date_of_request,
        "date_of_completion": req.date_of_completion or "Pending",
        "rating": req.rating,  # Include rating
        "feedback": req.feedback  # Include feedback
    } for req in requests]
    return jsonify({"service_requests": request_list}), 200


# Browse Offers for a Specific Service (search offers)
@bp.route('/browse_offers', methods=['GET'])
@login_required
@customer_required
def browse_offers():
    service_id = request.args.get('service_id')  # Optional filter
    query = ServiceOffer.query
    if service_id:
        query = query.filter_by(service_id=service_id)

    offers = query.all()
    offer_list = [{
        "offer_id": offer.id,
        "professional_id": offer.professional_id,
        "service_id": offer.service_id,
        "availability": offer.availability,
        "price": offer.price,
        "description": offer.description,
        "professional_name": offer.professional.username if offer.professional else "Unknown"
    } for offer in offers]
    return jsonify({"offers": offer_list}), 200


# Customer Profile Route (served by a template)
@bp.route('/profile', methods=['GET'])
@login_required
@customer_required
def profile():
    return render_template('customer_profile.html', user=current_user)


# Customer Dashboard Summary (Statistics)
@bp.route('/summary', methods=['GET'])
@login_required
@customer_required
def get_customer_summary():
    total_services_booked = ServiceRequest.query.filter_by(customer_id=current_user.id).count()
    total_services_completed = ServiceRequest.query.filter_by(customer_id=current_user.id, service_status="completed").count()
    total_services_assigned = ServiceRequest.query.filter_by(customer_id=current_user.id, service_status="assigned").count()

    return jsonify({
        "totalServicesBooked": total_services_booked,
        "totalServicesCompleted": total_services_completed,
        "totalServicesAssigned": total_services_assigned
    }), 200
