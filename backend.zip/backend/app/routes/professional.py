from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from app.models import ServiceOffer, ServiceRequest, Service, User
from app.extensions import db
from functools import wraps  # Add this import
bp = Blueprint('professional', __name__, url_prefix='/professional')    

# Decorator twrappero ensure the current user is a professionalfrom functools import wraps  # Add this import
# Decorator to ensure the current user is a professional
def professional_required(f):
    """Decorator to ensure the current user is a professional."""
    @wraps(f)  # Preserve the original function's metadata
    @login_required
    def professional_wrapper(*args, **kwargs):
        if current_user.role != 'professional':
            return jsonify({"message": "Unauthorized"}), 403
        return f(*args, **kwargs)
    return professional_wrapper

# Professional Dashboard - List all offers created by the professional
@bp.route('/dashboard', methods=['GET'])
@professional_required
def dashboard():
    page = request.args.get('page', 1, type=int)
    per_page = 10  # Number of items per page
    offers = ServiceOffer.query.filter_by(professional_id=current_user.id).paginate(page, per_page, False)
    
    offers_list = [{
        "id": offer.id,
        "service_id": offer.service_id,
        "availability": offer.availability,
        "price": offer.price,
        "description": offer.description
    } for offer in offers.items]

    return jsonify({
        "dashboard": {
            "offers": offers_list,
            "total": offers.total
        }
    }), 200

# Create a Service Offer
@bp.route('/offer_service', methods=['POST'])
@professional_required
def offer_service():
    data = request.get_json()
    service_id = data['service_id']
    
    # Validate that the service exists
    service = Service.query.get(service_id)
    if not service:
        return jsonify({"message": "Service not found"}), 404

    availability = data['availability']
    price = data['price']
    description = data.get('description', '')

    offer = ServiceOffer(
        professional_id=current_user.id,
        service_id=service_id,
        availability=availability,
        price=price,
        description=description
    )
    db.session.add(offer)
    db.session.commit()
    return jsonify({"message": "Service offer created successfully"}), 201

# Confirm a Service Request
@bp.route('/update_status/<int:request_id>', methods=['POST'])
@professional_required
def update_status(request_id):
    data = request.get_json()
    new_status = data.get("status")

    if new_status not in ["accepted", "rejected"]:
        return jsonify({"message": "Invalid status"}), 400

    service_request = ServiceRequest.query.get_or_404(request_id)

    if service_request.professional_id != current_user.id:
        return jsonify({"message": "Unauthorized"}), 403

    service_request.service_status = new_status
    db.session.commit()
    return jsonify({"message": f"Service request marked as {new_status}"}), 200


# Mark a Service Request as Completed
@bp.route('/complete_request/<int:request_id>', methods=['POST'])
@professional_required
def complete_request(request_id):
    # Find the service request
    service_request = ServiceRequest.query.get_or_404(request_id)

    # Ensure the professional is the one assigned to the request
    if service_request.professional_id != current_user.id:
        return jsonify({"message": "Unauthorized to complete this request"}), 403
    
    # Mark as completed
    service_request.service_status = "completed"
    db.session.commit()
    return jsonify({"message": "Service request marked as completed"}), 200


from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models import ServiceRequest

professional_bp = Blueprint('professional', __name__)

@bp.route('/summary', methods=['GET'])
@professional_required
def summary():
    received_count = ServiceRequest.query.filter_by(
        professional_id=current_user.id,
        service_status="requested"
    ).count()

    closed_count = ServiceRequest.query.filter_by(
        professional_id=current_user.id,
        service_status="completed"
    ).count()

    rejected_count = ServiceRequest.query.filter_by(
        professional_id=current_user.id,
        service_status="rejected"
    ).count()

    return jsonify({
        "received": received_count,
        "closed": closed_count,
        "rejected": rejected_count
    }), 200

# Decorator to ensure the current user is a professional
def professional_required(f):
    """Decorator to ensure the current user is a professional."""
    @wraps(f)
    @login_required
    def professional_wrapper(*args, **kwargs):
        if current_user.role != 'professional':
            return jsonify({"message": "Unauthorized"}), 403
        return f(*args, **kwargs)
    return professional_wrapper

# Fetch today's service requests for the professional
@bp.route('/today_services', methods=['GET'])
@professional_required
def today_services():
    # Fetch today's service requests for the professional
    services = ServiceRequest.query.filter_by(professional_id=current_user.id, service_status="requested").all()

    services_data = []
    for service in services:
        # Fetch customer details
        customer = User.query.get(service.customer_id)  # Corrected to User.query.get
        if customer and customer.role == 'customer':
            customer_name = customer.username
            customer_phone = customer.phone_number
            customer_location = customer.location_pincode

        # Fetch professional details (if needed)
        professional = User.query.get(service.professional_id)  # Corrected to User.query.get
        if professional and professional.role == 'professional':
            professional_name = professional.username
            professional_phone = professional.phone_number
            professional_location = professional.location_pincode

        # Prepare service data
        services_data.append({
            "id": service.id,
            "customer_name": customer_name,
            "customer_phone": customer_phone,
            "location": customer_location,
            "service_status": service.service_status,
            "date_of_request": service.date_of_request,
            "rating": service.rating if service.rating else "Not yet rated",  # Handling possible None value for rating
            "professional_name": professional_name,
            "professional_phone": professional_phone
        })

    return jsonify(services_data), 200


# List Closed services for the professional
@bp.route('/closed_services', methods=['GET'])
@professional_required
def closed_services():
    services = ServiceRequest.query.filter_by(
        professional_id=current_user.id,
        service_status="completed"
    ).all()

    closed_services = []
    for service in services:
        customer = User.query.get(service.customer_id)  # Corrected to User.query.get
        if customer and customer.role == 'customer':
            closed_services.append({
                "id": service.id,
                "customer_name": customer.username,
                "customer_phone": customer.phone_number,
                "location": customer.location_pincode,
                "date": service.date_of_completion,
                "rating": service.rating if service.rating else "Not yet rated"  # Handling possible None value for rating
            })

    return jsonify({"closed_services": closed_services}), 200


# Search for services
@bp.route('/search_services', methods=['POST'])
@professional_required
def search_services():
    data = request.get_json()
    date_filter = data.get("date")
    pincode_filter = data.get("pincode")
    rating_filter = data.get("rating")

    query = ServiceRequest.query.filter_by(professional_id=current_user.id)

    if date_filter:
        query = query.filter(ServiceRequest.date_of_request == date_filter)
    if pincode_filter:
        query = query.join(Service).filter(Service.location_pincode == pincode_filter)
    if rating_filter:
        query = query.filter(ServiceRequest.rating == rating_filter)

    services = query.all()

    results = []
    for service in services:
        customer = User.query.get(service.customer_id)  # Corrected to User.query.get
        if customer and customer.role == 'customer':
            results.append({
                "id": service.id,
                "customer_name": customer.username,
                "customer_phone": customer.phone_number,
                "location": customer.location_pincode,
                "date": service.date_of_request,
                "rating": service.rating if service.rating else "Not yet rated"  # Handling possible None value for rating
            })

    return jsonify({"search_results": results}), 200