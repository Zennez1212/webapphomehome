from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required, current_user
from app.models import User
from app.extensions import db

bp = Blueprint('profile', __name__, url_prefix='/profile')

@bp.route('/profile', methods=['GET'])
@login_required
def profile():
    # Fetch user data based on the logged-in user
    user_data = {
        'full_name': current_user.full_name,
        'email': current_user.email,
        'phone_number': current_user.phone_number,
        'location_pincode': current_user.location_pincode,
        'address': current_user.address,
        'experience': current_user.experience if current_user.role == 'professional' else None,
        'role': current_user.role,
        'is_approved': current_user.is_approved if current_user.role == 'professional' else None,
        'is_blocked': current_user.is_blocked if current_user.role == 'professional' else None
    }
    return jsonify(user_data)
