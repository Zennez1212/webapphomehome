# app/routes/auth.py
from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required
from app.models import User
from app.extensions import db

bp = Blueprint('auth', __name__, url_prefix='/api/auth')

# Route for User Registration
@bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()

    if not data or not all(key in data for key in ["username", "password", "role"]):
        return jsonify({"message": "Invalid input"}), 400

    username = data['username']
    password = generate_password_hash(data['password'])
    role = data['role']

    # Restrict registration to customers and professionals
    if role not in ['customer', 'professional']:
        return jsonify({"message": "Invalid role. Only 'customer' and 'professional' are allowed."}), 400

    if User.query.filter_by(username=username).first():
        return jsonify({"message": "Username already exists"}), 409

    user = User(username=username, password=password, role=role)
    db.session.add(user)
    db.session.commit()

    return jsonify({"message": "User created successfully"}), 201

# Route for User Login@bp.route('/login', methods=['GET', 'POST'])
from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token
from werkzeug.security import check_password_hash
from app.models import User


@bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    role = data.get('role')

    # Validate input
    if not username or not password or not role:
        return jsonify({"message": "Invalid input"}), 400

    # Query the user from the database
    user = User.query.filter_by(username=username, role=role).first()

    # Validate user existence and password
    if not user or not check_password_hash(user.password, password):
        return jsonify({"message": "Invalid credentials"}), 401

    # Create a JWT token
    token = create_access_token(identity={"id": user.id, "role": user.role})

    return jsonify({"token": token, "role": user.role}), 20000



@bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))