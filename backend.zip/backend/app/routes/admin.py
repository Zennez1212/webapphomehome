from flask import Blueprint, request, jsonify, send_file,render_template
from flask_login import login_required, current_user
from datetime import datetime, timedelta
import csv
import io
from app.models import Service, User, ServiceRequest
from app.extensions import db, token_required

bp = Blueprint('admin', __name__, url_prefix='/admin')


@bp.route('/export', methods=['POST'])
def trigger_csv_export():
    """
    Endpoint to trigger the CSV export task.
    """
    task = export_service_requests.apply_async()
    return jsonify({"message": "Export task initiated", "task_id": task.id}), 202


### UTILITIES ###

from functools import wraps  # Add this import

def admin_required(f):
    """Decorator to ensure the current user is an admin."""
    @wraps(f)  # Preserve the original function metadata
    @login_required
    def admin_wrapper(*args, **kwargs):
        if current_user.role != 'admin':
            return jsonify({"message": "Unauthorized"}), 403
        return f(*args, **kwargs)
    return admin_wrapper


### ADMIN DASHBOARD ###

# admin.py
@bp.route('/admin-dashboard', methods=['GET'])
@login_required
def admin_dashboard():
    if current_user.role != 'admin':
        return jsonify({'message': 'You do not have permission to access this resource'}), 403

    return render_template('admin_dashboard.html')  # Render admin dashboard template



### SERVICE MANAGEMENT ###

@bp.route('/services', methods=['POST'])
@admin_required
def create_service():
    data = request.get_json()
    service = Service(
        name=data['name'],
        price=data['price'],
        time_required=data['time_required'],
        description=data['description']
    )
    db.session.add(service)
    db.session.commit()

    return jsonify({"message": "Service created successfully", "service": {
        "id": service.id,
        "name": service.name,
        "price": service.price,
        "time_required": service.time_required
    }}), 201


@bp.route('/services', methods=['GET'])
@admin_required
def get_services():
    services = Service.query.all()
    service_list = [
        {
            "id": service.id,
            "name": service.name,
            "price": service.price,
            "time_required": service.time_required,
            "description": service.description
        }
        for service in services
    ]
    return jsonify({"services": service_list}), 200


### USER MANAGEMENT ###

def update_user_status(user_id, action):
    """Utility function to block/unblock or approve/reject users."""
    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    if action == "block":
        user.is_blocked = True
        message = f"User {user.username} has been blocked"
    elif action == "unblock":
        user.is_blocked = False
        message = f"User {user.username} has been unblocked"
    elif action == "approve":
        user.is_approved = True
        message = f"Service professional {user.username} approved"
    elif action == "reject":
        db.session.delete(user)
        message = f"Service professional {user.username} rejected and deleted"
    else:
        return jsonify({"message": "Invalid action"}), 400

    db.session.commit()
    return jsonify({"message": message, "user": {
        "id": user.id,
        "username": user.username,
        "role": user.role,
        "is_blocked": user.is_blocked,
        "is_approved": getattr(user, "is_approved", None)
    }}), 200


@bp.route('/users/<int:user_id>/unblock', methods=['POST'])
@admin_required
def unblock_user(user_id):
    return update_user_status(user_id, "unblock")


@bp.route('/professionals/<int:professional_id>/reject', methods=['POST'])
@admin_required
def reject_professional(professional_id):
    return update_user_status(professional_id, "reject")


### REPORT GENERATION ###

@bp.route('/reports/monthly', methods=['GET'])
@admin_required
def generate_monthly_report():
    # Filter service requests from the past month
    one_month_ago = datetime.now() - timedelta(days=30)
    service_requests = ServiceRequest.query.filter(
        ServiceRequest.date_of_request >= one_month_ago
    ).all()

    if not service_requests:
        return jsonify({"message": "No service requests found for the past month"}), 404

    # Prepare report data
    report_data = [
        {
            "Service ID": request.service_id,
            "Customer ID": request.customer_id,
            "Professional ID": request.professional_id,
            "Date of Request": request.date_of_request.strftime("%Y-%m-%d"),
            "Date of Completion": (request.date_of_completion.strftime("%Y-%m-%d") if request.date_of_completion else "Pending"),
            "Status": request.service_status,
            "Remarks": request.remarks or "None"
        }
        for request in service_requests
    ]

    # Generate a CSV file
    csv_file = io.StringIO()
    writer = csv.DictWriter(csv_file, fieldnames=report_data[0].keys())
    writer.writeheader()
    writer.writerows(report_data)
    csv_file.seek(0)

    # Return the file as a download
    return send_file(
        io.BytesIO(csv_file.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name='monthly_report.csv'
    )


@bp.route('/professionals/<int:professional_id>/approve', methods=['POST'])
@login_required
def approve_professional(professional_id):
    if current_user.role != 'admin':
        return jsonify({"message": "Unauthorized"}), 403

    professional = User.query.filter_by(id=professional_id, role='professional').first()
    if not professional:
        return jsonify({"message": "Service professional not found"}), 404

    professional.is_approved = True
    db.session.commit()
    return jsonify({"message": f"Service professional {professional.username} approved"}), 200


# Block a user
@bp.route('/users/<int:user_id>/block', methods=['POST'])
@login_required
def block_user(user_id):
    if current_user.role != 'admin':
        return jsonify({"message": "Unauthorized"}), 403

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    user.is_blocked = True
    db.session.commit()
    return jsonify({"message": f"User {user.username} has been blocked"}), 200


from flask import Blueprint, jsonify
from app.models import User, Service

admin_bp = Blueprint('admin', __name__)

@bp.route('/admin/summary', methods=['GET'])
@admin_required
def get_admin_summary():
    total_users = User.query.count()
    total_professionals = User.query.filter_by(role='professional').count()
    total_services = Service.query.count()
    total_service_requests = ServiceRequest.query.count()
    total_services_provided = ServiceRequest.query.filter_by(service_status='completed').count()
    total_services_rejected = ServiceRequest.query.filter_by(service_status='rejected').count()
    total_services_deleted = ServiceRequest.query.filter_by(service_status='deleted').count()

    return jsonify({
        "totalUsers": total_users,
        "totalProfessionals": total_professionals,
        "totalServices": total_services,
        "totalServiceRequests": total_service_requests,
        "totalServicesProvided": total_services_provided,
        "totalServicesRejected": total_services_rejected,
        "totalServicesDeleted": total_services_deleted
    }), 200



@bp.route('/professionals', methods=['GET'])
@admin_required
def get_professionals():
    professionals = User.query.filter_by(role='professional').all()
    professional_list = [
        {
            "id": professional.id,
            "name": professional.username,
            "experience": professional.experience,  # Assuming `experience` field exists
            "service": professional.service.name if professional.service else "N/A"
        }
        for professional in professionals
    ]
    return jsonify({"professionals": professional_list}), 200

@bp.route('/service_requests', methods=['GET'])
@admin_required
def get_service_requests():
    service_requests = ServiceRequest.query.all()
    service_request_list = [
        {
            "id": request.id,
            "professional_name": request.professional.username if request.professional else "N/A",
            "requested_date": request.date_of_request.strftime("%Y-%m-%d"),
            "status": request.service_status
        }
        for request in service_requests
    ]
    return jsonify({"service_requests": service_request_list}), 200

