# models.py
from datetime import datetime
from . import db  # Import db directly from the app initialization module
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

    
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'admin', 'customer', 'professional'
    phone_number = db.Column(db.String(15), nullable=False)
    location_pincode = db.Column(db.String(10), nullable=False)
    is_approved = db.Column(db.Boolean, default=False)  # For professionals
    is_blocked = db.Column(db.Boolean, default=False)

    # Additional fields
    full_name = db.Column(db.String(100), nullable=True)
    email = db.Column(db.String(120), unique=True, nullable=True)
    address = db.Column(db.String(200), nullable=True)
    experience = db.Column(db.Integer, nullable=True)  # Experience for professionals only

    # Relationships
    service_offers = db.relationship('ServiceOffer', backref='professional', lazy=True)
    service_requests = db.relationship('ServiceRequest', backref='professional', lazy=True)

    # Password verification
    def check_password(self, password):
        return check_password_hash(self.password, password)
    
    


class Service(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    time_required = db.Column(db.Integer, nullable=False)  # Time in minutes
    description = db.Column(db.String(200), nullable=True)

class ServiceRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    professional_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    service_id = db.Column(db.Integer, db.ForeignKey('service.id'))
    service_status = db.Column(db.String(20), default='requested')  # e.g., requested, completed, etc.
    date_of_request = db.Column(db.DateTime, default=datetime.utcnow)
    date_of_completion = db.Column(db.DateTime, nullable=True)
    remarks = db.Column(db.String(255), nullable=True)
    rating = db.Column(db.Float, nullable=True)  # New column for the rating (e.g., 1-5 scale)
    feedback = db.Column(db.String(255), nullable=True)  # Optional feedback

    customer = db.relationship('User', foreign_keys=[customer_id], backref='service_requests')
    professional = db.relationship('User', foreign_keys=[professional_id], backref='assigned_requests')
    service = db.relationship('Service', backref='service_requests')

class ServiceOffer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    professional_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('service.id'), nullable=False)
    availability = db.Column(db.String(100), nullable=False)  # Example: "Mon-Fri 9 AM - 5 PM"
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(255), nullable=True)

    professional = db.relationship('User', backref='offers', lazy=True)
    service = db.relationship('Service', backref='offers', lazy=True)

