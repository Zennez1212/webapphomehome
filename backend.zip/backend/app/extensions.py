from functools import wraps
from flask import request, jsonify, current_app
from flask_sqlalchemy import SQLAlchemy
from flask_caching import Cache
from redis import Redis
import json
import jwt
# Extensions
db = SQLAlchemy()
cache = Cache()
redis = Redis.from_url('redis://localhost:6379/0')

from flask_login import LoginManager

login_manager = LoginManager()

# JWT Token Decorator
def token_required(f):
    """
    Decorator to validate JWT tokens for secure access to protected routes.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            try:
                token = request.headers['Authorization'].split(" ")[1]
            except IndexError:
                return jsonify({'message': 'Invalid token format!'}), 403

        if not token:
            return jsonify({'message': 'Token is missing!'}), 403

        try:
            # Use current_app for app config
            secret_key = current_app.config['SECRET_KEY']
            data = jwt.decode(token, secret_key, algorithms=["HS256"])
            current_user = None  # This will be set below

            # Avoid direct imports here to avoid circular import
            from app.models import User  # Importing inside to avoid circular import
            current_user = User.query.filter_by(id=data['user_id']).first()

            if not current_user:
                return jsonify({'message': 'User not found'}), 403

            if current_user.is_blocked:
                return jsonify({'message': 'User is blocked. Access denied!'}), 403

        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'Token has expired! Please log in again.'}), 403
        except jwt.InvalidTokenError:
            return jsonify({'message': 'Invalid token!'}), 403
        except Exception as e:
            return jsonify({'message': str(e)}), 403

        return f(current_user, *args, **kwargs)

    return decorated_function

# Caching Utilities
def cache_services():
    """
    Cache all services in Redis for quick access.
    """
    from app.models import Service  # Importing inside to avoid circular import
    services = Service.query.all()
    services_data = [{"id": s.id, "name": s.name, "price": s.price, "description": s.description} for s in services]
    redis.setex('all_services', current_app.config.get('CACHE_TIMEOUT', 3600), json.dumps(services_data))  # Cache for 1 hour
    return services_data

def get_cached_services():
    """
    Retrieve services from Redis cache or database if cache is empty.
    """
    cached_services = redis.get('all_services')
    if cached_services:
        return jsonify({"services": json.loads(cached_services)}), 200

    # If no cache, fetch from DB and update cache
    services_data = cache_services()
    return jsonify({"services": services_data}), 200
