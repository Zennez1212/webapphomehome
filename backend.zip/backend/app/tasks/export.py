from app.celery import celery  # Import from app.celery
from app.models import ServiceRequest, Service, User
from app.extensions import db
import csv
import os
from datetime import datetime
from flask import current_app

@celery.task
def export_service_requests():
    """
    Celery task to export service requests into a CSV file.
    """
    try:
        # Define the CSV filename
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        filename = f"service_requests_{timestamp}.csv"
        filepath = os.path.join(current_app.config['EXPORT_FOLDER'], filename)
        
        # Fetch service requests from the database
        requests = db.session.query(ServiceRequest).all()
        
        # Create CSV file
        with open(filepath, mode='w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            
            # Write header
            writer.writerow([
                "Request ID", "Customer", "Service", "Professional", 
                "Status", "Remarks", "Requested Date", "Completion Date"
            ])
            
            # Write data rows
            for req in requests:
                writer.writerow([
                    req.id,
                    req.customer_id,
                    req.service_id,
                    req.professional_id or "Unassigned",
                    req.service_status,
                    req.remarks or "",
                    req.date_of_request.strftime('%Y-%m-%d %H:%M:%S'),
                    req.date_of_completion.strftime('%Y-%m-%d %H:%M:%S') if req.date_of_completion else "Pending"
                ])
        
        return f"Export completed successfully. File saved at: {filepath}"
    
    except Exception as e:
        return f"Export failed with error: {str(e)}"
