from flask import current_app
from app.models import ServiceRequest
from datetime import datetime, timedelta
import csv

def generate_monthly_report():
    one_month_ago = datetime.utcnow() - timedelta(days=30)
    requests = ServiceRequest.query.filter(ServiceRequest.date_of_request >= one_month_ago).all()

    with open('monthly_report.csv', 'w', newline='') as csvfile:
        fieldnames = ['Service ID', 'Customer ID', 'Professional ID', 'Date of Request', 'Status']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for request in requests:
            writer.writerow({
                'Service ID': request.service_id,
                'Customer ID': request.customer_id,
                'Professional ID': request.professional_id,
                'Date of Request': request.date_of_request,
                'Status': request.service_status,
            })

    print("Monthly report generated.")
