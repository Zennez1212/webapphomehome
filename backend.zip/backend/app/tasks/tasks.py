# app/tasks.py

from celery import Celery
from app import create_app
from app.models import ServiceRequest, User
from app.extensions import db
from datetime import datetime, timedelta

from app.celery import celery

@celery.task
def export_service_requests_to_csv():
    # Your task logic here
    pass


@celery.task
def send_daily_reminder():
    # Logic for sending daily reminders to professionals
    print("Daily reminder sent.")

@celery.task
def generate_monthly_report():
    one_month_ago = datetime.now() - timedelta(days=30)
    service_requests = ServiceRequest.query.filter(ServiceRequest.date_of_request >= one_month_ago).all()

    # Generate report logic here...
    print("Monthly report generated.")

@celery.task
def export_service_requests_as_csv():
    service_requests = ServiceRequest.query.all()

    # Generate CSV logic here...
    print("CSV export completed.")
