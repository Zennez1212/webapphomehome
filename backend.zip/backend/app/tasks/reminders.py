from app.models import ServiceRequest
from app.extensions import db
from datetime import datetime, timedelta

def send_daily_reminders():
    pending_requests = ServiceRequest.query.filter(
        ServiceRequest.service_status == "pending",
        ServiceRequest.date_of_request < datetime.utcnow() - timedelta(days=1)
    ).all()

    for request in pending_requests:
        # Logic to send reminders (via email, SMS, or Google Chat Webhooks)
        print(f"Reminder sent for ServiceRequest ID: {request.id}")
