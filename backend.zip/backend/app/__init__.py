from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_caching import Cache
from flask_migrate import Migrate  # Import Flask-Migrate
from app.extensions import db, login_manager, cache

# Initialize extensions
db = SQLAlchemy()
login_manager = LoginManager()
cache = Cache()
migrate = Migrate()  # Initialize Flask-Migrate

def create_app(config_class="config.Config"):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    cache.init_app(app)
    migrate.init_app(app, db)  # Initialize Flask-Migrate

    # Register Blueprints (Routes)
    from .routes import auth, admin, customer, professional  # Import your blueprints here
    app.register_blueprint(auth.bp)
    app.register_blueprint(admin.bp)
    app.register_blueprint(customer.bp)
    app.register_blueprint(professional.bp)

    # Define the default route
    @app.route('/')
    def home():
        return "Welcome to the Service Application API"

    return app

# User loader moved here
from app.models import User

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))
