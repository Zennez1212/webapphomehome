// frontend/src/router.js
import { createRouter, createWebHistory } from 'vue-router';

// Import your components
import Login from './components/Login.vue';
import Register from "../components/Register.vue";
// import ServiceList from './components/ServiceList.vue';
// import ServiceManagement from './components/ServiceManagement.vue';
// import NotFound from './components/NotFound.vue'; // For handling 404 pages
import SharedDashboardLayout from '@/components/SharedDashboardLayout.vue';
import AdminDashboard from '@/components/AdminDashboard.vue';
import CustomerDashboard from '@/components/CustomerDashboard.vue';
import ProfessionalDashboard from '@/components/ProfessionalDashboard.vue';
import Search from '@/components/Search';
import Summary from '@/components/Summary';
import Login from '@/components/Login';
const routes = [
  {
    path: '/',
    name: 'login',
    component: Login, // Default route goes to login
  },
  {
    path: '/services',
    name: 'services',
    component: ServiceList, // Public service listing
  },
  {
    path: '/admin-dashboard',
    name: 'admin-dashboard',
    component: AdminDashboard,
    meta: { requiresRole: 'admin' },
  },
  {
    path: '/professional-dashboard',
    name: 'professional-dashboard',
    component: ProfessionalDashboard,
    meta: { requiresRole: 'professional' },
  },
  {
    path: '/customer-dashboard',
    name: 'customer-dashboard',
    component: CustomerDashboard,
    meta: { requiresRole: 'customer' },
  },
  {
    path: '/Profile',
    name: 'Profile',
    component: Profile,
    meta: { requiresRole: 'customer' },
  },
  {
    path: '/admin/services',
    name: 'service-management',
    component: ServiceManagement,
    meta: { requiresRole: 'admin' }, // Restricted to admin
  },
  {
    path: '/:pathMatch(.*)*', // Catch-all for 404
    name: 'not-found',
    component: NotFound,
  }
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

// Add navigation guard for role-based access control
router.beforeEach((to, from, next) => {
  const role = localStorage.getItem('role'); // Fetch role from local storage
  const token = localStorage.getItem('token'); // Fetch token to check login status

  // If the route requires authentication and a role
  if (to.meta.requiresRole) {
    if (token) {
      if (role === to.meta.requiresRole) {
        next(); // Allow access if role matches
      } else {
        next('/'); // Redirect to login if role doesn't match
      }
    } else {
      next('/'); // Redirect to login if no token
    }
  } else {
    next(); // Allow access to public routes
  }
});

export default router;
