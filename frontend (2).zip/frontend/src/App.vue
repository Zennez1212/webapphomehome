<template>
  <div id="app">
    <header>
      <h1>Household Services Application</h1>
      <nav>
        <router-link to="/LoginRegister">Login</router-link>
        <router-link to="/UserRegister">Rddsegister</router-link>
        <!-- Conditional links based on user role -->
        <router-link to="/admin-dashboard" v-if="role === 'admin'">Admin Dashboard</router-link>
        <router-link to="/professional-dashboard" v-if="role === 'professional'">Professional Dashboard</router-link>
        <router-link to="/customer-dashboard" v-if="role === 'customer'">Customer Dashboard</router-link>
        <button v-if="role" @click="logout">Logout</button>
      </nav>
    </header>
    <main>
      <router-view />
    </main>
  </div>
</template>

<script>
export default {
  name: "App",
  computed: {
    role() {
      return localStorage.getItem("role");
    },
  },
  methods: {
    logout() {
      localStorage.removeItem("role");
      localStorage.removeItem("token");
      this.$router.push("/");
    },
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

header {
  background: #2c3e50;
  color: white;
  padding: 1rem;
}

nav {
  display: flex;
  justify-content: center;
  gap: 1rem;
  margin-top: 1rem;
}

nav a {
  color: white;
  text-decoration: none;
  padding: 0.5rem 1rem;
  background: #3e8ef7;
  border-radius: 5px;
}

nav a:hover {
  background: #2a6cb7;
}

button {
  background: #f44336;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background: #d32f2f;
}
</style>
