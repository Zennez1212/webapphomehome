import { createApp } from 'vue';
import App from './App.vue';
import router from './router';  // Import the router
import store from './store/store';

createApp(App)
  .use(store)
  .mount('#app');

createApp(App)
  .use(router)  // Tell Vue to use the router
  .mount('#app');
