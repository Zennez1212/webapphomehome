import { createStore } from "vuex";
import {
  getServices,
  createService,
  updateService,
  deleteService,
} from "../api"; // Ensure these are correctly implemented in ../api

export default createStore({
  state: {
    user: null,
    token: localStorage.getItem("token") || null,
    role: localStorage.getItem("role") || null,
    services: [], // Store the list of services
  },
  mutations: {
    // Authentication Mutations
    setUser(state, user) {
      state.user = user;
      localStorage.setItem("user", JSON.stringify(user));
    },
    setToken(state, token) {
      state.token = token;
      localStorage.setItem("token", token);
    },
    setRole(state, role) {
      state.role = role;
      localStorage.setItem("role", role);
    },
    logout(state) {
      state.user = null;
      state.token = null;
      state.role = null;
      state.services = [];
      localStorage.removeItem("token");
      localStorage.removeItem("role");
      localStorage.removeItem("user");
    },
    // Service Management Mutations
    SET_SERVICES(state, services) {
      state.services = services;
    },
    ADD_SERVICE(state, service) {
      state.services.push(service);
    },
    UPDATE_SERVICE(state, updatedService) {
      const index = state.services.findIndex((s) => s.id === updatedService.id);
      if (index !== -1) {
        state.services.splice(index, 1, updatedService);
      }
    },
    DELETE_SERVICE(state, serviceId) {
      state.services = state.services.filter((s) => s.id !== serviceId);
    },
  },
  actions: {
    // Authentication Actions
    async login({ commit }, credentials) {
      const response = await createService("/auth/login", credentials);
      const { access_token } = response.data;
      const decodedToken = JSON.parse(atob(access_token.split(".")[1]));
      commit("setToken", access_token);
      commit("setRole", decodedToken.role);
      commit("setUser", decodedToken);
    },
    logout({ commit }) {
      commit("logout");
    },

    // Service Management Actions
    async fetchServices({ commit }) {
      const services = await getServices();
      commit("SET_SERVICES", services);
    },
    async addService({ commit }, serviceData) {
      const newService = await createService(serviceData);
      commit("ADD_SERVICE", newService);
    },
    async editService({ commit }, updatedService) {
      const editedService = await updateService(updatedService);
      commit("UPDATE_SERVICE", editedService);
    },
    async removeService({ commit }, serviceId) {
      await deleteService(serviceId);
      commit("DELETE_SERVICE", serviceId);
    },
  },
});
