import axios from 'axios';

const API_URL = 'http://localhost:5000/api'; // Flask backend URL

// Create an Axios instance with default settings
export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});


// Register a new user
export const register = async (username, password, role) => {
  try {
    const response = await axios.post('http://127.0.0.1:5000/api/auth/register', {
      username,
      password,
      role,
    });
    return response.data;
  } catch (error) {
    console.error("Registration error:", error.response?.data || error.message);
    throw error;
  }
};

// frontend/src/api.js
export async function login(username, password, role) {
  const response = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password, role }),
  });
  if (!response.ok) {
    throw new Error('Login failed');
  }
  return response.json();
}

// Function to fetch services with an optional search query
export const getServices = async (searchQuery = "") => {
  try {
    const response = await axios.get(`${API_URL}/services`, {
      params: {
        query: searchQuery, // Pass the search query as a parameter
      },
    });
    return response.data;
  } catch (error) {
    console.error("Get services error:", error);
    throw error;
  }
};

// Create a new service
export const createService = async (serviceData) => {
  try {
    const token = localStorage.getItem('token');
    const response = await api.post('/services', serviceData, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error) {
    console.error("Create service error:", error);
    throw error;
  }
};


// Update an existing service
export const updateService = async (serviceData) => {
  try {
    const token = localStorage.getItem('token');
    const response = await api.put(`/services/${serviceData.id}`, serviceData, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error) {
    console.error("Update service error:", error);
    throw error;
  }
};

// Delete a service
export const deleteService = async (serviceId) => {
  try {
    const token = localStorage.getItem('token');
    await api.delete(`/services/${serviceId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
  } catch (error) {
    console.error("Delete service error:", error);
    throw error;
  }
};

// Create a new service request
export const createServiceRequest = async (customerId, serviceId, requestData) => {
  try {
    const response = await api.post(`/customers/${customerId}/service_requests`, {
      service_id: serviceId,
      ...requestData,
    });
    return response.data;
  } catch (error) {
    console.error("Create service request error:", error);
    throw error;
  }
};

// Fetch service requests for a specific customer
export const getServiceRequests = async (customerId) => {
  try {
    const response = await api.get(`/customers/${customerId}/service_requests`);
    return response.data;
  } catch (error) {
    console.error("Get service requests error:", error);
    throw error;
  }
};

// Professional Actions
export const acceptServiceRequest = async (professionalId, requestId) => {
  try {
    const response = await api.put(`/professionals/${professionalId}/service_requests/${requestId}/accept`);
    return response.data;
  } catch (error) {
    console.error("Accept service request error:", error);
    throw error;
  }
};

export const rejectServiceRequest = async (professionalId, requestId) => {
  try {
    const response = await api.put(`/professionals/${professionalId}/service_requests/${requestId}/reject`);
    return response.data;
  } catch (error) {
    console.error("Reject service request error:", error);
    throw error;
  }
};

// Admin Actions
export const blockUser = async (userId) => {
  try {
    const response = await api.put(`/admin/users/${userId}/block`);
    return response.data;
  } catch (error) {
    console.error("Block user error:", error);
    throw error;
  }
};

export const approveProfessional = async (professionalId) => {
  try {
    const response = await api.put(`/admin/professionals/${professionalId}/approve`);
    return response.data;
  } catch (error) {
    console.error("Approve professional error:", error);
    throw error;
  }
};
// Function to get the user profile
export const getUserProfile = async (token) => {
  try {
    const response = await axios.get(`${API_URL}/user/profile`, {
      headers: {
        'Authorization': `Bearer ${token}`, // Pass the token for authorization
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error fetching user profile:", error);
    throw error;
  }
};

// Fetch summary for admin
export const fetchAdminSummary = async () => {
  const response = await api.get('/admin/summary');
  return response.data;
};

// Fetch summary for professional
export const fetchProfessionalSummary = async () => {
  const response = await api.get('/professional/summary');
  return response.data;
};

// Fetch summary for customer
export const fetchCustomerSummary = async () => {
  const response = await api.get('/customer/summary');
  return response.data;
};