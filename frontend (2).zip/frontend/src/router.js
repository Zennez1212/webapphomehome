import { createRouter, createWebHistory } from 'vue-router';

// Import components
import LoginRegister from './components/LoginRegister.vue';
import ServiceList from './components/ServiceList.vue';
import Register from './components/UserRegister.vue';
import Home from './components/BaseHome.vue'; // Fix the import for Home
import UserProfile from '@/components/UserProfile.vue'; // Keep only the necessary import

const routes = [
  {
    path: '/',
    name: 'home',
    component: Home, // Set the default route to LoginRegister
  },
  { path: '/LoginRegister', component: LoginRegister },
  { path: '/UserRegister', component: Register },
  {
    path: '/services',
    name: 'services',
    component: ServiceList, // Public service listing
  },
  {
    path: '/UserProfile',
    name: 'UserProfile',
    component: UserProfile,
    meta: { requiresRole: ['customer', 'professional'] }, // Allow access for both roles
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

// Navigation guard for role-based access
router.beforeEach((to, from, next) => {
  const role = localStorage.getItem('role'); // Fetch role
  const token = localStorage.getItem('token'); // Check login status
  if (to.meta.requiresRole) {
    if (token) {
      if (to.meta.requiresRole.includes(role)) { // Fix: Check if role is allowed
        next(); // Role matches
      } else {
        next('/'); // Role mismatch
      }
    } else {
      next('/'); // Redirect to login if no token
    }
  } else {
    next(); // Public route
  }
});

export default router;
