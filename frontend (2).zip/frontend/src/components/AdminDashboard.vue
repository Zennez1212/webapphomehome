<template>
    <div>
      <!-- Dashboard Section -->
      <nav>
        <ul>
          <li><router-link to="/professional/dashboard">Dashboard</router-link></li>
          <li><router-link to="/professional/search">Search</router-link></li>
          <li><router-link to="/professional/summary">Summary</router-link></li>
          <li><button @click="logout">Logout</button></li>
        </ul>
      </nav>
      <div class="dashboard-section">
        <h2>Services</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Base Price</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="service in services" :key="service.id">
              <td>{{ service.id }}</td>
              <td>{{ service.name }}</td>
              <td>{{ service.base_price }}</td>
              <td>
                <button @click="editService(service.id)">Edit</button>
                <button @click="deleteService(service.id)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
  
        <h2>Professionals</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Experience (Years)</th>
              <th>Service</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="professional in professionals" :key="professional.id">
              <td>{{ professional.id }}</td>
              <td>{{ professional.name }}</td>
              <td>{{ professional.experience }}</td>
              <td>{{ professional.service.name }}</td>
              <td>
                <button @click="approveProfessional(professional.id)">Approve</button>
                <button @click="rejectProfessional(professional.id)">Reject</button>
                <button @click="deleteProfessional(professional.id)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
  
        <h2>Service Requests</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Assigned Professional</th>
              <th>Requested Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="request in serviceRequests" :key="request.id">
              <td>{{ request.id }}</td>
              <td>{{ request.professional_name }}</td>
              <td>{{ request.requested_date }}</td>
              <td>{{ request.status }}</td>
            </tr>
          </tbody>
        </table>
      </div>
  
      <!-- Search Section -->
      <div class="search-section">
        <h2>Search Services</h2>
        <form @submit.prevent="searchServices">
          <div>
            <label for="service">Service:</label>
            <input type="text" v-model="searchParams.service" />
          </div>
          <div>
            <label for="customer">Customer:</label>
            <input type="text" v-model="searchParams.customer" />
          </div>
          <div>
            <label for="professional">Professional:</label>
            <input type="text" v-model="searchParams.professional" />
          </div>
          <div>
            <label for="location">Location:</label>
            <input type="text" v-model="searchParams.location" />
          </div>
          <div>
            <label for="date">Date:</label>
            <input type="date" v-model="searchParams.date" />
          </div>
          <button type="submit">Search</button>
        </form>
  
        <h3>Search Results</h3>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Assigned Professional</th>
              <th>Requested Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="request in searchResults" :key="request.id">
              <td>{{ request.id }}</td>
              <td>{{ request.professional_name }}</td>
              <td>{{ request.requested_date }}</td>
              <td>{{ request.status }}</td>
            </tr>
          </tbody>
        </table>
      </div>
  
      <!-- Summary Section -->
      <div class="summary-section">
        <h2>Dashboard Summary</h2>
        <p>Customers: {{ summaryData.customers }}</p>
        <p>Professionals: {{ summaryData.professionals }}</p>
        <p>Services: {{ summaryData.services }}</p>
        <p>Services Provided: {{ summaryData.services_provided }}</p>
        <p>Services Rejected: {{ summaryData.services_rejected }}</p>
        <p>Services Deleted: {{ summaryData.services_deleted }}</p>
      </div>
      <router-view />
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        services: [],
        professionals: [],
        serviceRequests: [],
        searchResults: [],
        searchParams: {
          service: '',
          customer: '',
          professional: '',
          location: '',
          date: ''
        },
        summaryData: {
          customers: 0,
          professionals: 0,
          services: 0,
          services_provided: 0,
          services_rejected: 0,
          services_deleted: 0
        }
      };
    },
    created() {
      this.fetchServices();
      this.fetchProfessionals();
      this.fetchServiceRequests();
      this.fetchSummaryData();
    },
    methods: {
      async fetchServices() {
        const response = await axios.get('/admin/services');
        this.services = response.data;
      },
      async fetchProfessionals() {
        const response = await axios.get('/admin/professionals');
        this.professionals = response.data;
      },
      async fetchServiceRequests() {
        const response = await axios.get('/admin/service_requests');
        this.serviceRequests = response.data;
      },
      async fetchSummaryData() {
        const response = await axios.get('/admin/summary');
        this.summaryData = response.data;
      },
      async searchServices() {
        const response = await axios.post('/admin/search', this.searchParams);
        this.searchResults = response.data;
      },
      async editService(id) {
        // Call API to edit service
      },
      async deleteService(id) {
        // Call API to delete service
      },
      async approveProfessional(id) {
        // Call API to approve professional
      },
      async rejectProfessional(id) {
        // Call API to reject professional
      },
      async deleteProfessional(id) {
        // Call API to delete professional
      }
    }
  };
  </script>
  
  <style scoped>
  /* Add your styles here */
  </style>
  