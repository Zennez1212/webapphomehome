<template>
  <div class="services-container">
    <h2>Available Services</h2>
    <div v-if="loading" class="loading">Loading services...</div>
    <div v-else-if="services.length === 0" class="no-services">No services available.</div>
    <ul v-else>
      <li v-for="service in services" :key="service.id" class="service-item">
        <h3>{{ service.name }}</h3>
        <p>Price: ${{ service.price }}</p>
        <p v-if="service.description">{{ service.description }}</p>
        <button @click="handleServiceSelect(service)">Select Service</button>
      </li>
    </ul>
  </div>
</template>

<script>
import { getServices } from "../api";

export default {
  data() {
    return {
      services: [],
      loading: true, // Added loading state
      error: null,   // Added error state
    };
  },
  async mounted() {
    try {
      this.services = await getServices();
    } catch (err) {
      this.error = "Failed to load services. Please try again later.";
      console.error("Error fetching services:", err);
    } finally {
      this.loading = false; // Ensure loading stops regardless of success or failure
    }
  },
  methods: {
    handleServiceSelect(service) {
      // Placeholder for selecting a service
      alert(`You selected: ${service.name}`);
    },
  },
};
</script>

<style scoped>
.services-container {
  max-width: 600px;
  margin: auto;
  padding: 1rem;
  border: 1px solid #ccc;
  border-radius: 5px;
  background: #f9f9f9;
}

ul {
  list-style: none;
  padding: 0;
}

li.service-item {
  margin-bottom: 1rem;
  padding: 1rem;
  border: 1px solid #ddd;
  border-radius: 5px;
  background: #fff;
}

li.service-item h3 {
  margin: 0 0 0.5rem;
}

li.service-item p {
  margin: 0.25rem 0;
}

button {
  padding: 0.5rem 1rem;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

.loading, .no-services {
  text-align: center;
  color: #555;
}
</style>
