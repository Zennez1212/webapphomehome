<template>
    <div class="register-container">
      <h2>Register</h2>
      <form @submit.prevent="handleRegister">
        <div>
          <label for="username">Username</label>
          <input type="text" v-model="username" required />
        </div>
        <div>
          <label for="password">Password</label>
          <input type="password" v-model="password" required />
        </div>
        <div>
          <label for="role">Role</label>
          <select v-model="role" required>
            <option value="customer">Customer</option>
            <option value="professional">Professional</option>
          </select>
        </div>
        <button type="submit">Register</button>
        <p v-if="error">{{ error }}</p>
        <p>Already have an account? <router-link to="login-register">Login here</router-link></p>
      </form>
    </div>
  </template>
  
  <script>
  import { register } from "../api"; // Import the register API function
  
  export default {
    data() {
      return {
        username: "",
        password: "",
        role: "customer", // Default role
        error: null,
      };
    },
    methods: {
      async handleRegister() {
        try {
          await register(this.username, this.password, this.role);
          this.$router.push("/login"); // Redirect to login after successful registration
        } catch (err) {
          this.error = err.response?.data?.message || "Registration failed. Please try again.";
        }
      },
    },
  };
  </script>
  
  <style scoped>
  .register-container {
    max-width: 400px;
    margin: auto;
    padding: 1rem;
    border: 1px solid #ccc;
    border-radius: 5px;
    background: #f9f9f9;
  }
  </style>
  