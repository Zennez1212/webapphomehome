<template>
  <div class="login-container">
    <h2>Login</h2>
    <form @submit.prevent="handleLogin">
      <div>
        <label for="username">Username</label>
        <input
          type="text"
          id="username"
          v-model="username"
          required
        />
      </div>
      <div>
        <label for="password">Password</label>
        <input
          type="password"
          id="password"
          v-model="password"
          required
        />
      </div>
      <button type="submit">Login</button>
      <p v-if="error">{{ error }}</p>
    </form>
  </div>
</template>

<script>
import { login } from "../api"; // Import the login API function

export default {
  data() {
    return {
      username: "",
      password: "",
      error: null,
    };
  },
  methods: {
    async handleLogin() {
      try {
        const response = await login(this.username, this.password);
        localStorage.setItem("token", response.token); // Save JWT token
        localStorage.setItem("role", response.role);   // Save user role
        this.redirectUser(response.role);              // Redirect based on role
      } catch (err) {
        this.error = "Invalid credentials. Please try again.";
      }
    },
    redirectUser(role) {
      if (role === "admin") {
        this.$router.push("/admin-dashboard");
      } else if (role === "professional") {
        this.$router.push("/professional-dashboard");
      } else if (role === "customer") {
        this.$router.push("/customer-dashboard");
      }
    },
  },
};
</script>

<style scoped>
.login-container {
  max-width: 400px;
  margin: auto;
  padding: 1rem;
  border: 1px solid #ccc;
  border-radius: 5px;
  background: #f9f9f9;
}
</style>
