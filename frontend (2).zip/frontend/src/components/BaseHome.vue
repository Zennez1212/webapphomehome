<template>
  <div>
    <h2>Welcome to Household Services Application</h2>
  </div>
</template>

<script>
export default {
  name: "BaseHome",
};
</script>

<style scoped>
/* Style for the Home page buttons */
button {
  margin: 10px;
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
  border: none;
  background-color: #3e8ef7;
  color: white;
  border-radius: 5px;
}

button:hover {
  background-color: #2a6cb7;
}
</style>
