<template>
    <div>
      <!-- Dashboard Section -->
      <nav>
        <ul>
          <li><router-link to="/customer/dashboard">Dashboard</router-link></li>
          <li><router-link to="/customer/search">Search</router-link></li>
          <li><router-link to="/customer/summary">Summary</router-link></li>
          <li><router-link to="/profile">Profile</router-link></li>
          <li><button @click="logout">Logout</button></li>
        </ul>
      </nav>
      <section>
        <h3>Looking For</h3>
        <div v-for="service in services" :key="service.id">
          <span>{{ service.name }}</span>
        </div>
      </section>
  
      <section>
        <h3>Service History</h3>
        <table>
          <thead>
            <tr>
              <th>Service Name</th>
              <th>Professional Name</th>
              <th>Status</th>
              <th>Rating</th>
              <th>Feedback</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="history in serviceHistory" :key="history.id">
              <td>{{ history.service_name }}</td>
              <td>{{ history.professional_name }}</td>
              <td>{{ history.status }}</td>
              <td>{{ history.rating ? history.rating : 'Not rated' }}</td>
              <td>{{ history.feedback ? history.feedback : 'No feedback' }}</td>
            </tr>
          </tbody>
        </table>
      </section>
  
      <!-- Search Section -->
      <section>
        <input v-model="searchQuery" placeholder="Search for services, professionals, or location"/>
        <button @click="searchServices()">Search</button>
      </section>
  
      <section>
        <table>
          <thead>
            <tr>
              <th>Service Name</th>
              <th>Professional Name</th>
              <th>Phone No.</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="result in searchResults" :key="result.id">
              <td>{{ result.service_name }}</td>
              <td>{{ result.professional_name }}</td>
              <td>{{ result.phone_no }}</td>
              <td><button @click="bookService(result.id)">Book</button></td>
            </tr>
          </tbody>
        </table>
      </section>
  
      <!-- Summary Section -->
      <section>
        <h3>Summary</h3>
        <p>Services Booked: {{ summary.totalServicesBooked }}</p>
        <p>Services Completed: {{ summary.totalServicesCompleted }}</p>
        <p>Services Assigned: {{ summary.totalServicesAssigned }}</p>
      </section>
      <router-view />
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        services: [], // List of available services
        serviceHistory: [], // Service history for customer
        searchResults: [], // Search results
        summary: {}, // Summary statistics
        searchQuery: '', // Search query input
      };
    },
    methods: {
      async fetchData() {
        try {
          // Fetch available services (Looking For)
          const servicesResponse = await fetch('/customer/browse_offers');
          const servicesData = await servicesResponse.json();
          this.services = servicesData.offers.map(offer => ({
            id: offer.id,
            name: offer.service_name,
          }));
  
          // Fetch service history
          const historyResponse = await fetch('/customer/service_requests');
          const historyData = await historyResponse.json();
          this.serviceHistory = historyData.service_requests;
  
          // Fetch summary stats
          const summaryResponse = await fetch('/customer/summary');
          const summaryData = await summaryResponse.json();
          this.summary = summaryData;
  
        } catch (error) {
          console.error('Error fetching data:', error);
        }
      },
  
      async searchServices() {
        try {
          const response = await fetch(`/customer/browse_offers?service_name=${this.searchQuery}`);
          const searchData = await response.json();
          this.searchResults = searchData.offers;
        } catch (error) {
          console.error('Error searching services:', error);
        }
      },
  
      async bookService(serviceId) {
        try {
          // Implement booking functionality if needed, you may have an API for booking.
          const bookingResponse = await fetch(`/customer/service_requests`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              service_id: serviceId,
              remarks: 'Booking request for service',
            }),
          });
          const bookingResult = await bookingResponse.json();
          if (bookingResult.message === 'Service request created successfully') {
            alert('Service booked successfully!');
            this.fetchData(); // Reload data to show the updated status
          }
        } catch (error) {
          console.error('Error booking service:', error);
          alert('Failed to book the service.');
        }
      },
    },
    mounted() {
      this.fetchData();
    },
  };
  </script>
  
  <style scoped>
  /* Add your styles here */
  </style>
  