<template>
  <div>
    <!-- Check if the user is logged in and redirect them accordingly -->
    <div v-if="role">
      <router-view /> <!-- This renders the role-specific dashboard -->
    </div>
    <div v-else>
      <p>Please log in to view your dashboard.</p>
    </div>
  </div>
</template>

<script>
export default {
  computed: {
    role() {
      return localStorage.getItem("role"); // Get role from localStorage
    },
  },
  watch: {
    role(newRole) {
      // If role is set, navigate to the appropriate dashboard page
      if (newRole) {
        this.redirectToDashboard(newRole);
      }
    },
  },
  methods: {
    redirectToDashboard(role) {
      if (role === "admin") {
        this.$router.push("/admin-dashboard");
      } else if (role === "customer") {
        this.$router.push("/customer-dashboard");
      } else if (role === "professional") {
        this.$router.push("/professional-dashboard");
      }
    },
  },
};
</script>
