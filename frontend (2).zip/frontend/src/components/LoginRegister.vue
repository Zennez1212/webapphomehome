<template>
    <div class="login-register-container">
      <h2>Login/Register</h2>
      <form @submit.prevent="handleLogin">
        <div>
          <label for="username">Username</label>
          <input type="text" v-model="username" required />
        </div>
        <div>
          <label for="password">Password</label>
          <input type="password" v-model="password" required />
        </div>
        <div>
          <label for="role">Role</label>
          <select v-model="role" required>
            <option value="admin">Admin</option>
            <option value="customer">Customer</option>
            <option value="professional">Professional</option>
          </select>
        </div>
        <button type="submit">Login</button>
        <p v-if="error">{{ error }}</p>
        <p>Don't have an account? <router-link to="/register">Register here</router-link></p>
      </form>
    </div>
  </template>
  
  <script>
  import { login } from "../api"; // Import the login API function
  
  export default {
    data() {
      return {
        username: "",
        password: "",
        role: "customer", // Default to "customer"
        error: null,
      };
    },
    methods: {
      async handleLogin() {
        try {
          const response = await login(this.username, this.password, this.role); // Pass role to login function
          localStorage.setItem("token", response.token); // Save JWT token
          localStorage.setItem("role", response.role);   // Save user role
          this.redirectUser(response.role);              // Redirect based on role
        } catch (err) {
          this.error = "Invalid credentials. Please try again.";
        }
      },
      redirectUser(role) {
        if (role === "admin") {
          this.$router.push("/admin-dashboard");
        } else if (role === "professional") {
          this.$router.push("/professional-dashboard");
        } else if (role === "customer") {
          this.$router.push("/customer-dashboard");
        }
      },
    },
  };
  </script>
  
  <style scoped>
  .login-register-container {
    max-width: 400px;
    margin: auto;
    padding: 1rem;
    border: 1px solid #ccc;
    border-radius: 5px;
    background: #f9f9f9;
  }
  </style>
  