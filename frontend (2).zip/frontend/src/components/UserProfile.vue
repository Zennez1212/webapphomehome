<template>
  <div>
    <section>
      <h3>User Profile</h3>
      <p><strong>Full Name:</strong> {{ user.full_name }}</p>
      <p><strong>Email:</strong> {{ user.email }}</p>
      <p><strong>Phone Number:</strong> {{ user.phone_number }}</p>
      <p><strong>Location:</strong> {{ user.location_pincode }}</p>
      <p><strong>Address:</strong> {{ user.address }}</p>

      <!-- Display experience only for professionals -->
      <p v-if="user.role === 'professional'"><strong>Experience:</strong> {{ user.experience }} years</p>

      <!-- Additional fields for approval and block status (for professionals only) -->
      <p v-if="user.role === 'professional'"><strong>Approval Status:</strong> {{ user.is_approved ? 'Approved' : 'Not Approved' }}</p>
      <p v-if="user.role === 'professional'"><strong>Blocked:</strong> {{ user.is_blocked ? 'Yes' : 'No' }}</p>
    </section>
  </div>
</template>

<script>
export default {
  data() {
    return {
      user: {} // User data will be fetched here
    };
  },
  methods: {
    async fetchUserData() {
      const response = await fetch('/profile/profile');
      this.user = await response.json();
    }
  },
  mounted() {
    this.fetchUserData();
  }
};
</script>
