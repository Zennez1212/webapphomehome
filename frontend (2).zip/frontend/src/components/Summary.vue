<template>
    <div>
      <h2>Summary</h2>
      <div v-if="role === 'admin'">
        <p>Total Users: {{ summary.totalUsers }}</p>
        <p>Total Professionals: {{ summary.totalProfessionals }}</p>
        <p>Total Services: {{ summary.totalServices }}</p>
      </div>
      <div v-if="role === 'professional'">
        <p>Total Accepted Requests: {{ summary.acceptedRequests }}</p>
        <p>Pending Requests: {{ summary.pendingRequests }}</p>
      </div>
      <div v-if="role === 'customer'">
        <p>Total Service Requests: {{ summary.totalRequests }}</p>
        <p>Completed Requests: {{ summary.completedRequests }}</p>
      </div>
    </div>
  </template>
  
  <script>
  import { fetchAdminSummary, fetchProfessionalSummary, fetchCustomerSummary } from "../api";
  
  export default {
    data() {
      return {
        summary: {}, // Holds the fetched summary data
      };
    },
    computed: {
      role() {
        return localStorage.getItem("role");
      },
    },
    async mounted() {
      try {
        // Fetch summary data based on role
        if (this.role === "admin") {
          this.summary = await fetchAdminSummary();
        } else if (this.role === "professional") {
          this.summary = await fetchProfessionalSummary();
        } else if (this.role === "customer") {
          this.summary = await fetchCustomerSummary();
        }
      } catch (error) {
        console.error("Error fetching summary data:", error);
      }
    },
  };
  </script>
  