<template>
  <div>
    <h2>Service Management</h2>

    <!-- Add Service Form -->
    <form @submit.prevent="handleAddService">
      <input v-model="newService.name" placeholder="Service Name" required />
      <input v-model.number="newService.price" type="number" placeholder="Price" required />
      <button type="submit">Add Service</button>
    </form>

    <!-- Services List -->
    <ul>
      <li v-for="service in services" :key="service.id">
        <input v-model="service.name" @blur="updateService(service)" />
        <input
          v-model.number="service.price"
          type="number"
          @blur="updateService(service)"
        />
        <button @click="deleteService(service.id)">Delete</button>
      </li>
    </ul>
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";

export default {
  data() {
    return {
      newService: {
        name: "",
        price: null,
      },
    };
  },
  computed: {
    ...mapState(["services"]),
  },
  methods: {
    ...mapActions(["fetchServices", "addService", "editService", "removeService"]),
    async handleAddService() {
      if (!this.newService.name || this.newService.price === null) {
        alert("Please fill out all fields.");
        return;
      }
      try {
        await this.addService(this.newService);
        this.newService = { name: "", price: null }; // Reset form
      } catch (error) {
        console.error("Error adding service:", error);
      }
    },
    async updateService(service) {
      try {
        await this.editService(service);
      } catch (error) {
        console.error("Error updating service:", error);
      }
    },
    async deleteService(serviceId) {
      try {
        await this.removeService(serviceId);
      } catch (error) {
        console.error("Error deleting service:", error);
      }
    },
  },
  async mounted() {
    try {
      await this.fetchServices();
    } catch (error) {
      console.error("Error fetching services:", error);
    }
  },
};
</script>

<style scoped>
form {
  margin-bottom: 1rem;
}
ul {
  list-style: none;
  padding: 0;
}
li {
  display: flex;
  gap: 1rem;
  align-items: center;
  margin-bottom: 0.5rem;
}
button {
  margin-left: auto;
  padding: 0.3rem 0.6rem;
  background: #007bff;
  color: white;
  border: none;
  border-radius: 3px;
  cursor: pointer;
}
button:hover {
  background: #007bff;
}
input {
  padding: 0.3rem;
  border: 1px solid #ccc;
  border-radius: 3px;
}
</style>
