<template>
    <div>
      <h2>Welcome to the Dashboard</h2>
      <p>Here are the available services:</p>
      <ul>
        <li v-for="service in services" :key="service.id">
          {{ service.name }} - ${{ service.price }}
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  import { getServices } from '../api';
  
  export default {
    data() {
      return {
        services: [],
      };
    },
    async created() {
      this.services = await getServices();
    },
  };
  </script>
  