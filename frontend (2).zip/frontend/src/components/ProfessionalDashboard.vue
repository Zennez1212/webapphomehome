<template>
  <div>
    <!-- Dashboard -->
    <nav>
      <ul>
        <li><router-link to="/professional/dashboard">Dashboard</router-link></li>
        <li><router-link to="/professional/search">Search</router-link></li>
        <li><router-link to="/professional/summary">Summary</router-link></li>
        <li><router-link to="/profile">Profile</router-link></li>
        <li><button @click="logout">Logout</button></li>
      </ul>
    </nav> 
    <div class="dashboard-section">
      <h2>Today's Services</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Customer Name</th>
            <th>Customer Phone</th>
            <th>Location (Pincode)</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="service in todayServices" :key="service.id">
            <td>{{ service.id }}</td>
            <td>{{ service.customer_name }}</td>
            <td>{{ service.customer_phone }}</td>
            <td>{{ service.location }}</td>
            <td>
              <button @click="acceptService(service.id)">Accept</button>
              <button @click="rejectService(service.id)">Reject</button>
            </td>
          </tr>
        </tbody>
      </table>

      <h2>Closed Services</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Customer Name</th>
            <th>Customer Phone</th>
            <th>Location (Pincode)</th>
            <th>Date</th>
            <th>Rating</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="service in closedServices" :key="service.id">
            <td>{{ service.id }}</td>
            <td>{{ service.customer_name }}</td>
            <td>{{ service.customer_phone }}</td>
            <td>{{ service.location }}</td>
            <td>{{ service.date_of_completion }}</td>
            <td>{{ service.rating }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Search Section -->
    <div class="search-section">
      <h2>Search Services</h2>
      <form @submit.prevent="searchServices">
        <div>
          <label for="date">Date:</label>
          <input type="date" v-model="searchParams.date" />
        </div>
        <div>
          <label for="pincode">Pincode:</label>
          <input type="text" v-model="searchParams.pincode" />
        </div>
        <div>
          <label for="rating">Rating:</label>
          <input type="number" v-model="searchParams.rating" min="1" max="5" />
        </div>
        <button type="submit">Search</button>
      </form>

      <h3>Search Results</h3>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Customer Name</th>
            <th>Customer Phone</th>
            <th>Location (Pincode)</th>
            <th>Date</th>
            <th>Rating</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="service in searchResults" :key="service.id">
            <td>{{ service.id }}</td>
            <td>{{ service.customer_name }}</td>
            <td>{{ service.customer_phone }}</td>
            <td>{{ service.location }}</td>
            <td>{{ service.date_of_request }}</td>
            <td>{{ service.rating }}</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Summary Section -->
    <div class="summary-section">
      <h2>Service Request Summary</h2>
      <div id="bar-chart" style="height: 300px;"></div>
    </div>
    <router-view />
  </div>
</template>

<script>
import { mapState } from 'vuex';
import axios from 'axios';
import { Chart } from 'chart.js';

export default {
  data() {
    return {
      todayServices: [],
      closedServices: [],
      searchResults: [],
      searchParams: {
        date: '',
        pincode: '',
        rating: ''
      },
      summaryData: {
        received: 0,
        closed: 0,
        rejected: 0
      }
    };
  },
  created() {
    this.fetchTodayServices();
    this.fetchClosedServices();
    this.fetchServiceSummary();
  },
  methods: {
    // Fetch today's services
    async fetchTodayServices() {
      try {
        const response = await axios.get('/professional/today_services');
        this.todayServices = response.data;
      } catch (error) {
        console.error('Error fetching today\'s services:', error);
      }
    },

    // Fetch closed services
    async fetchClosedServices() {
      try {
        const response = await axios.get('/professional/closed_services');
        this.closedServices = response.data;
      } catch (error) {
        console.error('Error fetching closed services:', error);
      }
    },

    // Accept service request
    async acceptService(serviceId) {
      try {
        await axios.post(`/professional/update_status/${serviceId}`, { status: 'accepted' });
        this.fetchTodayServices(); // Refresh the services after accepting
      } catch (error) {
        console.error('Error accepting service:', error);
      }
    },

    // Reject service request
    async rejectService(serviceId) {
      try {
        await axios.post(`/professional/update_status/${serviceId}`, { status: 'rejected' });
        this.fetchTodayServices(); // Refresh the services after rejecting
      } catch (error) {
        console.error('Error rejecting service:', error);
      }
    }


    // Search services based on parameters
    async searchServices() {
      try {
        const response = await axios.post('/professional/search_services', this.searchParams);
        this.searchResults = response.data.search_results;
      } catch (error) {
        console.error('Error searching services:', error);
        alert('Search failed. Please try again later.');
      }
    },

    // Fetch service request summary for bar chart
    async fetchServiceSummary() {
      try {
        const response = await axios.get('/professional/summary');
        this.summaryData = response.data;
        this.renderBarChart();
      } catch (error) {
        console.error('Error fetching summary:', error);
      }
    },

    // Render the bar chart for summary
    renderBarChart() {
      const ctx = document.getElementById('bar-chart').getContext('2d');
      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: ['Received', 'Closed', 'Rejected'],
          datasets: [{
            label: 'Service Requests',
            data: [this.summaryData.received, this.summaryData.closed, this.summaryData.rejected],
            backgroundColor: ['rgba(54, 162, 235, 0.2)', 'rgba(75, 192, 192, 0.2)', 'rgba(153, 102, 255, 0.2)'],
            borderColor: ['rgba(54, 162, 235, 1)', 'rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)'],
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });
    }
  }
};
</script>

<style scoped>
.dashboard-section,
.search-section,
.summary-section {
  margin-bottom: 2rem;
}

h2 {
  font-size: 1.5rem;
  margin-bottom: 1rem;
}

table {
  width: 100%;
  border-collapse: collapse;
}

table th, table td {
  border: 1px solid #ccc;
  padding: 0.5rem;
  text-align: left;
}

button {
  padding: 0.5rem 1rem;
  margin: 0.5rem;
  background-color: #4CAF50;
  color: white;
  border: none;
  cursor: pointer;
}

button:hover {
  background-color: #45a049;
}

form {
  margin-bottom: 1rem;
}

form div {
  margin-bottom: 1rem;
}

form label {
  margin-right: 0.5rem;
}
</style>
