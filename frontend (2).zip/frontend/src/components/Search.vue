<template>
    <div>
      <h2>Search Services</h2>
      <input type="text" v-model="searchQuery" placeholder="Search for services..." />
      <button @click="searchServices">Search</button>
  
      <!-- Loading state -->
      <div v-if="loading">Loading...</div>
  
      <!-- No results state -->
      <div v-if="noResults">No services found matching your query.</div>
  
      <!-- Search results -->
      <ul v-if="services.length && !noResults">
        <li v-for="service in services" :key="service.id">
          {{ service.name }} - ${{ service.price }}
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  import { getServices } from "../api";
  
  export default {
    data() {
      return {
        searchQuery: "",
        services: [],
        loading: false,
        noResults: false, // To handle when no results are found
      };
    },
    methods: {
      async searchServices() {
        if (!this.searchQuery.trim()) {
          this.services = [];
          return;
        }
        
        this.loading = true;
        this.noResults = false;
  
        try {
          const response = await getServices(this.searchQuery);
          this.services = response.data;
  
          // If no services match, display a message
          if (this.services.length === 0) {
            this.noResults = true;
          }
        } catch (error) {
          console.error("Search error", error);
          this.noResults = true; // Show no results message on error
        } finally {
          this.loading = false;
        }
      },
    },
  };
  </script>
  